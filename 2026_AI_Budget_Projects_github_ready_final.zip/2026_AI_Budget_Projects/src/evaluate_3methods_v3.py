"""
Recompute final 3-method summary tables from the saved long-format evaluation file.

Input:
  results/final/final_eval_long_vector_xlsx_rdfsparql_v3.csv

Outputs:
  results/final/overall_summary_3methods_v3.csv
  results/final/type_summary_3methods_v3.csv

This script does not re-run LLM calls, vector retrieval, SPARQL, or XLSX executor.
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
EVAL_LONG_PATH = ROOT / "results/final/final_eval_long_vector_xlsx_rdfsparql_v3.csv"
OUT_DIR = ROOT / "results/final"

EXPECTED_METHODS = [
    "Plain Text Vector RAG",
    "RDF Template SPARQL v3",
    "XLSX Template Executor v4",
]


def main():
    if not EVAL_LONG_PATH.exists():
        raise FileNotFoundError(f"Missing file: {EVAL_LONG_PATH}")

    eval_long = pd.read_csv(EVAL_LONG_PATH)
    required = {"id", "type", "method", "precision", "recall", "f1"}
    missing = required - set(eval_long.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    methods = set(eval_long["method"].unique())
    missing_methods = [m for m in EXPECTED_METHODS if m not in methods]
    if missing_methods:
        raise ValueError(f"Missing expected methods: {missing_methods}")

    overall = eval_long.groupby("method").agg(
        n=("id", "count"),
        precision=("precision", "mean"),
        recall=("recall", "mean"),
        f1=("f1", "mean"),
        f1_ge_07=("f1", lambda x: (x >= 0.7).mean()),
    ).reset_index()

    for c in ["precision", "recall", "f1", "f1_ge_07"]:
        overall[c] = (overall[c] * 100).round(2)

    type_summary = eval_long.groupby(["method", "type"]).agg(
        n=("id", "count"),
        precision=("precision", "mean"),
        recall=("recall", "mean"),
        f1=("f1", "mean"),
    ).reset_index()

    for c in ["precision", "recall", "f1"]:
        type_summary[c] = (type_summary[c] * 100).round(2)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    overall.to_csv(OUT_DIR / "overall_summary_3methods_v3.csv", index=False, encoding="utf-8-sig")
    type_summary.to_csv(OUT_DIR / "type_summary_3methods_v3.csv", index=False, encoding="utf-8-sig")

    print("Overall summary")
    print(overall.to_string(index=False))
    print("\nType summary")
    print(type_summary.to_string(index=False))


if __name__ == "__main__":
    main()
