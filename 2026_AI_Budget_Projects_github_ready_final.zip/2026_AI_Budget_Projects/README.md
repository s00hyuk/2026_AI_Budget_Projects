# 2026 AI Budget Projects: AI-Ready Structuring and Queryability Evaluation

This repository provides reproducibility materials for the paper:

**A Study on AI-Ready Structuring Methodology for Korean Government Budget Explanation Templates: Queryability Comparison of Metadata, RDF Graph, XLSX Table, and Plain Text RAG**

## Overview

This study investigates how Korean government budget explanation documents can be transformed into AI-ready data representations. The main case study uses **533 AI-related government budget projects in 2026** and evaluates 100 structured QA questions.

The final evaluation compares three methods:

1. **Plain Text Vector RAG**
2. **RDF Template SPARQL v3**
3. **XLSX Template Executor v4**

Important interpretation note:

- Plain Text Vector RAG receives natural-language questions and answers from retrieved text.
- RDF Template SPARQL v3 and XLSX Template Executor v4 use human-authored `query_logic` and execute structured queries over RDF graph and XLSX-derived tables.
- Therefore, RDF/XLSX results should be interpreted as **queryability under given query_logic**, or quasi-upper-bound structured query performance, not fully automatic Text-to-SPARQL/Text-to-SQL performance.

## Final Reported Results

### Overall performance

| Method | Precision | Recall | F1 | F1 >= 0.7 |
|---|---:|---:|---:|---:|
| Plain Text Vector RAG | 50.17 | 39.33 | 42.20 | 29.0 |
| RDF Template SPARQL v3 | 62.67 | 60.00 | 60.77 | 50.0 |
| XLSX Template Executor v4 | 79.02 | 80.00 | 79.19 | 67.0 |

### Paired bootstrap results

| Comparison | Mean F1 diff. (%p) | 95% CI | p-value |
|---|---:|---:|---:|
| RDF - Vector | 18.57 | [8.77, 28.23] | <0.001 |
| XLSX - Vector | 36.99 | [27.77, 46.09] | <0.001 |
| XLSX - RDF | 18.42 | [9.81, 27.16] | <0.001 |

## Repository Structure

```text
2026_AI_Budget_Projects/
├── README.md
├── requirements.txt
├── LICENSE
├── CITATION.cff
├── data/
│   ├── goldset/
│   └── predictions/
├── results/
│   ├── final/
│   └── bootstrap/
├── notebooks/
├── src/
├── docs/
└── schema/
```

## Quick Start

Install dependencies:

```bash
pip install -r requirements.txt
```

Reproduce final summary tables from the saved per-question evaluation file:

```bash
python src/evaluate_3methods_v3.py
```

Reproduce paired bootstrap confidence intervals:

```bash
python src/bootstrap_3methods_v3.py
```

The final reported scores can be reproduced **without re-running LLM calls** using the saved prediction and evaluation files included in this repository.

## Key Files

```text
data/predictions/final_comparison_vector_xlsx_rdfsparql_v3.csv
results/final/final_eval_long_vector_xlsx_rdfsparql_v3.csv
results/final/overall_summary_3methods_v3.csv
results/final/type_summary_3methods_v3.csv
results/bootstrap/per_question_f1_wide_3methods_v3.csv
results/bootstrap/paired_bootstrap_3methods_v3_percent.csv
results/bootstrap/paired_bootstrap_by_type_3methods_v3_percent.csv
```

## Reproducibility Notes

- `acceptable_answers` are used only for evaluation, not for answer generation.
- RDF/XLSX methods use `query_logic`; they are not end-to-end natural-language query systems.
- Re-running original Vector RAG generation may require an OpenAI API key.
- OpenAI API outputs may not be bit-level reproducible due to model updates and server-side nondeterminism.
- The reported evaluation scores are reproducible from saved prediction/evaluation files and the scripts in `src/`.

## Documentation

- `docs/query_logic_spec.md`: query_logic DSL summary
- `docs/data_dictionary.md`: expected table structure and normalization policy
- `docs/reproducibility_notes.md`: exact scope of reproducibility and limitations

## License and Citation

See `LICENSE` and `CITATION.cff`.
