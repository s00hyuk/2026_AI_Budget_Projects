# Data Dictionary

## df_base

Project-level table. Each row corresponds to one budget project.

Typical fields:

- 사업번호
- 사업명
- 소관
- 회계/기금
- 분야명
- 부문명
- 프로그램명
- 단위사업명
- 세부사업명
- 사업성격 신규/계속/완료
- 지원형태 직접/출자/출연/보조/융자
- 사업시행주체_목록
- 2026년 예산
- 전년대비 증감액

## df_subj

Detail-project or implementing-agency-level table.

Typical fields:

- 사업번호
- 사업명
- 내역사업명
- 시행기관
- 지원금액
- 지원비율

## Normalization Policies

1. Business-name unique count normalization:
   - NFKC normalization
   - remove whitespace
   - remove Korean middle dot variants

2. Implementing agency contains matching:
   - split by `|`, `,`, `/`
   - exact part matching
   - limited alias dictionary: NIA, NIPA, IITP, KDB, TIPA

3. Ministry field:
   - raw exact matching
   - no blanket whitespace normalization

These policies were chosen to match the final goldset construction logic and avoid over-normalizing ministry names that were intentionally raw-matched.
