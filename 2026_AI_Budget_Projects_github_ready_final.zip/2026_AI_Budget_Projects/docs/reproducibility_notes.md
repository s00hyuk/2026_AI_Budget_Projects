# Reproducibility Notes

## What can be reproduced without LLM calls?

The final reported F1 scores and paired bootstrap confidence intervals can be reproduced from saved files:

- `results/final/final_eval_long_vector_xlsx_rdfsparql_v3.csv`
- `src/evaluate_3methods_v3.py`
- `src/bootstrap_3methods_v3.py`

## What requires external API calls?

Re-generating Plain Text Vector RAG predictions from scratch may require:

- OpenAI API access
- embedding model setup
- vector database setup

Because commercial LLM APIs may change over time, bit-level reproduction of generated answers is not guaranteed.

## Interpretation of structured methods

RDF Template SPARQL v3 and XLSX Template Executor v4 are not end-to-end natural-language QA systems. They use human-authored `query_logic` and therefore estimate structured queryability under a given query interpretation.
