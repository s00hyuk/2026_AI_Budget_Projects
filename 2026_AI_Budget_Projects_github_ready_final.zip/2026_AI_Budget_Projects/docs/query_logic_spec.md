# query_logic DSL Specification

`query_logic` is a human-authored domain-specific query representation used to execute structured queries over RDF graph and XLSX table representations.

## Purpose

The DSL makes each gold question executable and auditable by specifying:

- source table or source columns
- filter conditions
- join or relation traversal logic
- result operation such as list, count, sum, max, or unique

## Example Patterns

```text
사업시행주체_목록 contains {'한국지능정보사회진흥원'} -> unique 사업명 count
소관={'과학기술 정보통신부'} AND 지원형태_출연=TRUE -> 2026예산 sum
소관={'과학기술 정보통신부'} AND 신규=TRUE -> max 2026예산 사업명
사업시행주체_목록 contains {'한국산업은행'} -> unique (소관, 지원형태_목록) pair list
```

## Counting Basis

Counting questions must explicitly indicate whether the count is based on:

- rows in `df_base`
- rows in `df_subj`
- unique project IDs
- unique project names
- `contains` matching over agency-list columns

This is necessary because the same agency can appear multiple times across base projects, detail projects, and agency-list columns.

## No-Oracle Principle

`acceptable_answers` are not used to generate predictions. They are used only by the evaluator.
