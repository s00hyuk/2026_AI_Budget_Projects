# Schema Files

This folder is reserved for RDF/OWL schema artifacts.

If public release of full TTL/OWL files is allowed, place them here, for example:

- `budget_schema.ttl`
- `public_ai_budget_sample.ttl`
- `public_ai_budget.owl`

The current reproducibility package focuses on final evaluation and bootstrap results. The RDF/SPARQL method outputs are represented in the prediction and evaluation CSV files.
